import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button, Alert, Vibration } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Audio } from 'expo-av';

export default function Feedback() {
  const [message, setMessage] = useState('');
  const [score, setScore] = useState('');
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const router = useRouter();
  const { id } = useLocalSearchParams();

  const playSound = async () => {
    const { sound } = await Audio.Sound.createAsync(
      require('../../../assets/success.mp3')
    );
    setSound(sound);
    await sound.playAsync();
  };

  const handleSubmit = async () => {
    if (!message || !score) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    try {
      const response = await fetch(`https://api-exam-dpm-2024-production.up.railway.app/feedback/${id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message, score: Number(score) }),
      });

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`);
      }

      await playSound();
      Alert.alert('Sucesso', 'Feedback enviado com sucesso!', [
        { text: 'OK', onPress: () => router.push('/') }
      ]);
    } catch (error) {
      Vibration.vibrate();
      Alert.alert('Erro', 'Ocorreu um erro ao enviar o feedback.');
      console.error('Erro ao enviar feedback:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enviar Feedback</Text>
      <TextInput
        style={styles.input}
        placeholder="Mensagem"
        value={message}
        onChangeText={setMessage}
      />
      <TextInput
        style={styles.input}
        placeholder="Pontuação (0-10)"
        value={score}
        onChangeText={setScore}
        keyboardType="numeric"
      />
      <Button title="Enviar" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
});