import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

interface StatueInfoProps {
  name: string;
  birthYear: number;
  deathYear: number;
  nationality: string;
  imageUrl: string;
  material: string;
}

const materialColors: { [key: string]: string } = {
  Gesso: '#D3D3D3',
  Bronze: '#CD7F32',
  Madeira: '#8B4513',
  Mármore: '#FFFFFF',
  Ouro: '#FFD700',
};

export default function StatueInfo({ name, birthYear, deathYear, nationality, imageUrl, material }: StatueInfoProps) {
  const materialColor = materialColors[material] || '#000000';

  return (
    <View style={[styles.container, { borderColor: materialColor }]}>
      <Text style={styles.title}>{name}</Text>
      <View style={styles.infoContainer}>
        <FontAwesome name="birthday-cake" size={24} color="black" />
        <Text style={styles.infoText}>Born: {birthYear}</Text>
      </View>
      <View style={styles.infoContainer}>
        <FontAwesome name="times-circle" size={24} color="black" />
        <Text style={styles.infoText}>Died: {deathYear}</Text>
      </View>
      <Text style={styles.infoText}>Nationality: {nationality}</Text>
      <Image source={{ uri: imageUrl }} style={styles.image} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderWidth: 2,
    borderRadius: 8,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  infoText: {
    fontSize: 18,
    marginLeft: 8,
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 8,
  },
});