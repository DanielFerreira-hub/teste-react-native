import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Button, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import StatueInfo from '../../componentes/StatueInfo';

interface Artist {
  id: number;
  name: string;
  birthYear: number;
  deathYear: number;
  nationalityId: string;
  imageUrl: string;
  nationality: {
    id: string;
    name: string;
  };
  material: string;
}

export default function ArtistDetail() {
  const [artist, setArtist] = useState<Artist | null>(null);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { id } = useLocalSearchParams();

  useEffect(() => {
    const fetchArtist = async () => {
      try {
        const response = await fetch(`https://api-exam-dpm-2024-production.up.railway.app/artists/${id}`);
        if (!response.ok) {
          throw new Error(`Erro ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        setArtist(data);
      } catch (error) {
        const errorMessage = (error as Error).message;
        setError(errorMessage);
        Alert.alert('Erro', errorMessage, [
          { text: 'OK', onPress: () => router.push('/paginas/artista') }
        ]);
        console.error('Erro ao buscar artista:', error);
      }
    };

    fetchArtist();
  }, [id]);

  return (
    <View style={styles.container}>
      {error ? (
        <Text style={styles.error}>{error}</Text>
      ) : artist ? (
        <>
          <StatueInfo
            name={artist.name}
            birthYear={artist.birthYear}
            deathYear={artist.deathYear}
            nationality={artist.nationality.name}
            imageUrl={artist.imageUrl}
            material={artist.material}
          />
          <Button title="Back" onPress={() => router.back()} />
          <Button title="Enviar Feedback" onPress={() => router.push(`/paginas/feedback/${id}`)} />
        </>
      ) : (
        <Text>Loading...</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
  },
  error: {
    fontSize: 18,
    color: 'red',
  },
});