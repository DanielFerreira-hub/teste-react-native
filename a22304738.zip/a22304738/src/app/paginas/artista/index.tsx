import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, FlatList, Alert, Image } from 'react-native';
import { useRouter } from 'expo-router';

interface Artist {
  id: number;
  name: string;
  birthYear: number;
  deathYear: number;
  nationalityId: string;
  imageUrl: string;
  nationality: {
    id: string;
    name: string;
  };
}

export default function Artista() {
  const [artists, setArtists] = useState<Artist[]>([]);
  const [filteredArtists, setFilteredArtists] = useState<Artist[]>([]);
  const [search, setSearch] = useState('');
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchArtists = async () => {
      try {
        const response = await fetch('https://api-exam-dpm-2024-production.up.railway.app/artists');
        if (!response.ok) {
          throw new Error(`Erro ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        setArtists(data.artists);
        setFilteredArtists(data.artists);
      } catch (error) {
        const errorMessage = (error as Error).message;
        setError(errorMessage);
        Alert.alert('Erro', errorMessage, [
          { text: 'OK', onPress: () => router.push('/') }
        ]);
        console.error('Erro ao buscar artistas:', error);
      }
    };

    fetchArtists();
  }, []);

  const handleSearch = (text: string) => {
    setSearch(text);
    const filtered = artists.filter(artist => artist.name.toLowerCase().includes(text.toLowerCase()));
    setFilteredArtists(filtered);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Artists</Text>
      <TextInput
        style={styles.input}
        placeholder="Search by name"
        value={search}
        onChangeText={handleSearch}
      />
      {error ? (
        <Text style={styles.error}>{error}</Text>
      ) : (
        <FlatList
          data={filteredArtists}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.artistContainer}>
              <Text style={styles.artistName}>{item.name}</Text>
              <Text style={styles.artistInfo}>Nationality: {item.nationality.name}</Text>
              <Image source={{ uri: item.imageUrl }} style={styles.artistImage} />
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  error: {
    fontSize: 18,
    color: 'red',
  },
  artistContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  artistName: {
    fontSize: 24,
  },
  artistInfo: {
    fontSize: 18,
    color: '#555',
  },
  artistImage: {
    width: 100,
    height: 100,
    marginTop: 8,
  },
});